#ifndef PERF_ANALYZER_H
#define PERF_ANALYZER_H

#include <stdio.h>
#include <stdbool.h>
#include "platform.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "xgpio.h"
#include "xtmrctr.h"
#include "xintc.h"
#include "xtmrctr_l.h"
#include "xintc_l.h"
#include "mb_interface.h"
#include <xbasic_types.h>
#include <xio.h>



#define PROF_MAX_REGIONS  8
#define PROF_MAX_BUCKETS  256

typedef struct {
    uint32_t start_addr;
    uint32_t end_addr;
    uint16_t first_bucket;
    uint8_t  bucket_shift;
    uint8_t  enabled;
} ProfRegionConfig;

typedef struct {
    uint32_t          num_regions;
    ProfRegionConfig  regions[PROF_MAX_REGIONS];
    uint16_t          other_bucket;
    volatile uint32_t bucket_counts[PROF_MAX_BUCKETS];
} ProfConfig;

extern ProfConfig g_prof;

void Prof_InitConfig(void);
void Prof_ClearCounts(void);
int  Prof_AddRegion(uint32_t start_addr, uint32_t end_addr,
                    uint8_t bucket_shift,
                    uint16_t first_bucket, uint16_t num_buckets);
void Prof_SetOtherBucket(uint16_t idx);

void performance_analyzer_setup_buckets(void);
int  performance_analyzer_init(void);
void per_anal_ISR(void *CallBackRef, u8 TmrCtrNumber);
void Prof_PrintAll(void);

#endif
