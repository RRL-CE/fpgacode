/*
 * Copyright (c) 2009-2012 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "xil_cache.h"
#include <mb_interface.h>

#include "xparameters.h"
#include <xil_types.h>
#include <xil_assert.h>

#include <xio.h>
#include "xtmrctr.h"
#include "fft.h"
#include "note.h"
#include "stream_grabber.h"

#include <stdint.h>



//added by me
#include "performance_analyzer.h"

#define SAMPLES 512 // AXI4 Streaming Data FIFO has size 512//I made it 4x bigger
//this *4 gives the 2048 used to calcualte sampling frequency, this is because with decimation/4-1 averaging by 4, period increases by 4 so freq decreases by 4
#define M 9 //2^m=samples
#define CLOCK 100000000.0 //clock speed

int int_buffer[2048];
// OLD:
// static float q[SAMPLES];
// static float w[SAMPLES];

// NEW:
static int32_t q[SAMPLES];   // Q1.31 real
static int32_t w[SAMPLES];   // Q1.31 imag (usually 0)

unsigned seqf, seql, seq_old=0;

//void print(char *str);

void read_fsl_values(float* q, int n) {
    int i;
    unsigned int x;

    // We will read RAW_SAMPLES from the FPGA, then do 4-to-1 averaging
    // to get OUT_SAMPLES effective samples.
    const int RAW_SAMPLES   = 2048;   // from stream_grabber
    const int DECIM_FACTOR  = 4;
    const int OUT_SAMPLES   = RAW_SAMPLES / DECIM_FACTOR;

    // Safety: don't overrun q[n]
    int max_out = OUT_SAMPLES;
    if (max_out > n) {
        max_out = n;
    }

    stream_grabber_start();
    stream_grabber_wait_enough_samples(RAW_SAMPLES);
    seql = stream_grabber_read_seq_counter();          // last seq when done
    seqf = stream_grabber_read_seq_counter_latched();  // seq when start was called

    // Read RAW_SAMPLES from hardware into int_buffer
    for (i = 0; i < RAW_SAMPLES; i++) {
        int_buffer[i] = stream_grabber_read_sample(i);
    }

    // 4-to-1 averaging:
    // Each output sample is the average of 4 consecutive raw samples.
    for (i = 0; i < max_out; i++) {
        int idx = i * DECIM_FACTOR;
        long sum =
            (long)int_buffer[idx] +
            (long)int_buffer[idx + 1] +
            (long)int_buffer[idx + 2] +
            (long)int_buffer[idx + 3];

        float avg = (float)sum / 4.0f;

        q[i] = 3.3f * avg / 67108864.0f; // 3.3V and 2^26 precision
    }

    // Zero-pad the rest of q up to n (FFT length, e.g. 512)
    for (i = max_out; i < n; i++) {
        q[i] = 0.0f;
    }
}


int main() {
   float sample_f;
   int l;
   int ticks; //used for timer
   uint32_t Control;
   float frequency;

   Xil_ICacheInvalidate();
   Xil_ICacheEnable();
   Xil_DCacheInvalidate();
   Xil_DCacheEnable();

   //set up timer
   XTmrCtr timer;
   XTmrCtr_Initialize(&timer, XPAR_TMRCTR_0_DEVICE_ID);
   Control = XTmrCtr_GetOptions(&timer, 0) | XTC_CAPTURE_MODE_OPTION | XTC_INT_MODE_OPTION;
   XTmrCtr_SetOptions(&timer, 0, Control);//control option on a Nexys A7100 board does the following:

   performance_analyzer_init();

                                          


   // print("Hello World\n\r");//not needed

   XTmrCtr_Start(&timer, 0);
   int i = 300;

   while (i > 0) {
       // Read values
       read_fsl_values(q, SAMPLES);

       ticks = XTmrCtr_GetValue(&timer, 0);
       printf("Time %d, Seqf %d, Seql %d, Seq_off %d\n",
              ticks, seqf, seql, seqf - seq_old);
       seq_old = seql;

       sample_f = 100 * 1000 * 1000 / 8192.0f;

       // zero imaginary part
       for (l = 0; l < SAMPLES; l++)
           w[l] = 0.0f;

       // --- FFT timing start ---
       u32 fft_t0 = XTmrCtr_GetValue(&timer, 0);

       // --- FFT ---
       float freq = fft(q, w, SAMPLES, M, sample_f);

       u32 fft_t1 = XTmrCtr_GetValue(&timer, 0);

       // Up-counter elapsed ticks
       u32 fft_ticks;
       if (fft_t1 >= fft_t0)
           fft_ticks = fft_t1 - fft_t0;
       else{
           fft_ticks = 0xFFFFFFFFu - fft_t0 + fft_t1 + 1u;
       }

       u32 fft_ms = fft_ticks / 100000u;    // 100,000 ticks per ms @ 100 MHz

       xil_printf("frequency: %d Hz, FFT_ticks: %u, FFT_ms: %u\r\n",
                  (int)(freq + 0.5f),
                  fft_ticks,
                  fft_ms);
        i--;
   }

   Prof_PrintAll();

   return 0;
}
